from pyResearchInsights.common_functions import argument_parser

keywords, trends = argument_parser()
scraper_main(keywords)